<?php

namespace App\Actions\Bookings;

use App\Enums\StayScope;
use App\Models\Booking;
use App\Models\Customer;
use App\Models\Hotel;
use App\Models\RoomType;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class CreateBookingAction
{
    public function handle(array $data): Booking
    {
        for ($attempt = 1; $attempt <= 3; $attempt++) {
            try {
                return DB::transaction(function () use ($data): Booking {
                    $normalized = $this->validateAndNormalize($data);
                    $booking = new Booking($normalized['booking']);
                    $booking->booking_number = ((int) Booking::query()->lockForUpdate()->max('booking_number')) + 1;
                    $booking->created_by = auth()->id();
                    $booking->updated_by = auth()->id();
                    $booking->save();

                    $this->syncRelations($booking, $normalized);

                    return $booking->fresh(['details.rooms', 'residents']);
                });
            } catch (QueryException $exception) {
                if ($attempt === 3 || ! $this->isUniqueViolation($exception)) {
                    throw $exception;
                }
            }
        }

        throw new \LogicException('تعذر إنشاء الحجز.');
    }

    /**
     * @return array{booking: array<string, mixed>, details: array<int, array<string, mixed>>, residents: array<int, int>, rooms: array<int, array<string, mixed>>}
     */
    public function validateAndNormalize(array $data): array
    {
        $user = auth()->user();
        if ($user && ! $user->isMainAdmin() && (! $user->isBranchEmployee() || ! $user->broker_id)) {
            throw ValidationException::withMessages(['broker_id' => 'يجب ربط المستخدم بفرع قبل إنشاء الحجز.']);
        }

        $brokerId = $user && ! $user->isMainAdmin()
            ? $user->broker_id
            : ($data['broker_id'] ?? null);

        $rooms = array_values(array_filter($data['rooms'] ?? [], fn (mixed $room): bool => filled($room['room_type_id'] ?? null)));
        if ($rooms === []) {
            throw ValidationException::withMessages(['rooms' => 'يجب إضافة غرفة واحدة على الأقل.']);
        }

        $scopeState = $data['stay_scope'] ?? StayScope::Both;
        $scope = $scopeState instanceof StayScope ? $scopeState->value : (int) $scopeState;
        $details = [];
        foreach ($this->citiesForScope($scope) as $city => $prefix) {
            $detail = [
                'city_id' => $city,
                'hotel_id' => $data[$prefix.'_hotel_id'] ?? null,
                'company_id' => $data[$prefix.'_company_id'] ?? null,
                'meal_id' => $data[$prefix.'_meal_id'] ?? null,
                'check_in' => $data[$prefix.'_check_in'] ?? null,
                'check_out' => $data[$prefix.'_check_out'] ?? null,
            ];

            if (! $detail['hotel_id'] || ! $detail['company_id'] || ! $detail['meal_id'] || ! $detail['check_in'] || ! $detail['check_out']) {
                throw ValidationException::withMessages([$prefix.'_hotel_id' => 'بيانات الفندق والجهات والتواريخ مطلوبة.']);
            }

            if (! Hotel::query()->whereKey($detail['hotel_id'])->where('city_id', $city)->exists()) {
                throw ValidationException::withMessages([$prefix.'_hotel_id' => 'الفندق المحدد لا يتبع المدينة المختارة.']);
            }

            if ($detail['check_out'] < $detail['check_in']) {
                throw ValidationException::withMessages([$prefix.'_check_out' => 'تاريخ الخروج يجب أن يكون بعد الدخول.']);
            }

            $details[] = $detail;
        }

        $customerId = (int) ($data['customer_id'] ?? 0);
        $customer = Customer::query()->with('dependents')->find($customerId);
        if (! $customer) {
            throw ValidationException::withMessages(['customer_id' => 'ولي الأمر مطلوب.']);
        }

        $residents = array_values(array_unique([
            $customerId,
            ...$customer->dependents->modelKeys(),
        ]));

        $total = 0.0;
        foreach ($rooms as &$room) {
            $roomType = RoomType::query()->find($room['room_type_id']);
            if (! $roomType) {
                throw ValidationException::withMessages(['rooms' => 'نوع الغرفة المحدد غير موجود.']);
            }

            $room['price'] = round((float) ($room['price'] ?? $roomType->price), 2);
            $room['total_price'] = round($room['price'] * (int) $roomType->size, 2);
            $total += $room['total_price'];
        }
        unset($room);

        $serviceAmount = round((float) ($data['service_amount'] ?? 0), 2);
        $discount = round((float) ($data['discount'] ?? 0), 2);
        if ($discount > ($total + $serviceAmount)) {
            throw ValidationException::withMessages(['discount' => 'التخفيض لا يمكن أن يتجاوز إجمالي الحجز والإضافي.']);
        }

        return [
            'booking' => [
                'customer_id' => $customerId,
                'broker_id' => $brokerId,
                'airplane_id' => $data['airplane_id'] ?? null,
                'booking_type_id' => $data['booking_type_id'] ?? null,
                'notes' => $data['notes'] ?? null,
                'services_note' => $data['services_note'] ?? null,
                'service_amount' => $serviceAmount,
                'total_amount' => $total,
                'discount' => $discount,
                'net_amount' => round($total + $serviceAmount - $discount, 2),
                'stay_scope' => $scope,
            ],
            'details' => $details,
            'residents' => $residents,
            'rooms' => $rooms,
        ];
    }

    /** @param array{booking: array<string, mixed>, details: array<int, array<string, mixed>>, residents: array<int, int>, rooms: array<int, array<string, mixed>>} $normalized */
    public function syncRelations(Booking $booking, array $normalized): void
    {
        $booking->residents()->createMany(array_map(fn (int $customerId): array => ['customer_id' => $customerId], $normalized['residents']));

        foreach ($normalized['details'] as $detailData) {
            $detail = $booking->details()->create($detailData);
            $detail->rooms()->createMany(array_map(
                fn (array $room): array => [
                    'room_type_id' => $room['room_type_id'],
                    'price' => $room['price'],
                    'total_price' => $room['total_price'],
                ],
                $normalized['rooms'],
            ));
        }
    }

    /** @return array<int, string> */
    protected function citiesForScope(int $scope): array
    {
        return match ($scope) {
            1 => [2 => 'madina'],
            2 => [1 => 'makka'],
            default => [2 => 'madina', 1 => 'makka'],
        };
    }

    protected function isUniqueViolation(QueryException $exception): bool
    {
        return $exception->getCode() === '23000' || str_contains(strtolower($exception->getMessage()), 'unique');
    }
}
