<?php

namespace App\Actions\Bookings;

use App\Models\Booking;
use Illuminate\Support\Facades\DB;

class UpdateBookingAction
{
    public function handle(Booking $booking, array $data): Booking
    {
        return DB::transaction(function () use ($booking, $data): Booking {
            $creator = app(CreateBookingAction::class);
            $normalized = $creator->validateAndNormalize($data);
            $booking->fill($normalized['booking']);
            $booking->updated_by = auth()->id();
            $booking->save();
            $booking->residents()->delete();
            $booking->details()->each(function ($detail): void {
                $detail->rooms()->delete();
                $detail->delete();
            });
            $creator->syncRelations($booking, $normalized);

            return $booking->fresh(['details.rooms', 'residents']);
        });
    }
}
