<?php

namespace App\Filament\Resources\Bookings\Schemas;

use App\Actions\Customers\CreateGuardianAction;
use App\Enums\StayScope;
use App\Models\Company;
use App\Models\Customer;
use App\Models\Hotel;
use App\Models\Meal;
use App\Models\RoomType;
use Filament\Forms\Components\DatePicker;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\Repeater;
use Filament\Forms\Components\Repeater\TableColumn;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\Textarea;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\ToggleButtons;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Components\Tabs;
use Filament\Schemas\Components\Tabs\Tab;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Carbon;

class BookingForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Tabs::make('booking_tabs')
                    ->tabs([
                        self::mainTab(),
                        self::stayTab(),
                        self::roomsTab(),
                        self::financeTab(),
                    ])
                    ->persistTabInQueryString()
                    ->columnSpanFull(),
            ]);
    }

    protected static function mainTab(): Tab
    {
        return Tab::make('بيانات الحجز')
            ->icon(Heroicon::OutlinedClipboardDocumentList)
            ->schema([
                Section::make()->schema([
                    Select::make('customer_id')
                        ->label('ولي الأمر')
                        ->relationship('customer', 'name_ar', modifyQueryUsing: fn (Builder $query): Builder => $query->whereNull('guardian_id'))
                        ->searchable()
                        ->preload()
                        ->live()
                        ->required()
                        ->createOptionForm([
                            TextInput::make('name_ar')->label('اسم ولي الأمر')->required(),
                            TextInput::make('phone')->label('الهاتف')->tel(),
                        ])
                        ->createOptionUsing(fn (array $data): int => app(CreateGuardianAction::class)->handle($data)->getKey())
                        ->afterStateUpdated(function (?int $state, Set $set): void {
                            $dependents = $state
                                ? Customer::query()
                                    ->where('guardian_id', $state)
                                    ->orderBy('id')
                                    ->get(['name_ar', 'name_en', 'phone'])
                                    ->map(fn (Customer $dependent): array => [
                                        'name_ar' => $dependent->name_ar,
                                        'name_en' => $dependent->name_en,
                                        'phone' => $dependent->phone,
                                    ])
                                    ->all()
                                : [];

                            $set('guardian_dependents', $dependents);
                        }),
                    TextInput::make('booking_number')
                        ->label('رقم الحجز')
                        ->placeholder('يُولَّد عند الحفظ')
                        ->prefixIcon(Heroicon::OutlinedHashtag)
                        ->disabled()
                        ->dehydrated(false),
                    Select::make('booking_type_id')->label('نوع الحجز')->relationship('bookingType', 'name')->searchable()->preload(),
                    Select::make('broker_id')
                        ->label('الفرع')
                        ->relationship('broker', 'name')
                        ->searchable()
                        ->preload()
                        ->visible(fn (): bool => auth()->user()?->isMainAdmin() ?? false),
                    Placeholder::make('assigned_branch')
                        ->label('الفرع')
                        ->content(fn (): string => auth()->user()?->broker?->name ?? 'الفرع غير محدد')
                        ->visible(fn (): bool => auth()->user() !== null && ! auth()->user()->isMainAdmin()),
                    Select::make('airplane_id')->label('الطيران')->relationship('airplane', 'name')->searchable()->preload(),
                ])->columns(2),
                Section::make('المعتمرون التابعون')
                    ->schema([
                        Repeater::make('guardian_dependents')
                            ->hiddenLabel()
                            ->table([
                                TableColumn::make('اسم المعتمر'),
                                TableColumn::make('الاسم بالإنجليزية'),
                                TableColumn::make('الهاتف'),
                            ])
                            ->schema([
                                TextInput::make('name_ar')
                                    ->disabled()
                                    ->dehydrated(false),
                                TextInput::make('name_en')
                                    ->disabled()
                                    ->dehydrated(false),
                                TextInput::make('phone')
                                    ->disabled()
                                    ->dehydrated(false),
                            ])
                            ->defaultItems(0)
                            ->addable(false)
                            ->deletable(false)
                            ->reorderable(false)
                            ->dehydrated(false),
                    ]),
                Section::make('نطاق الإقامة')
                    ->description('اختر المدن اللي هتتضمنها الإقامة، وهتظهر بيانات الفنادق حسب اختيارك.')
                    ->schema([
                        ToggleButtons::make('stay_scope')
                            ->hiddenLabel()
                            ->options(StayScope::class)
                            ->grouped()
                            ->default(StayScope::Both)
                            ->live()
                            ->disabledOn('edit')
                            ->required(),
                    ]),
                Section::make('ملاحظات')
                    ->collapsible()
                    ->schema([
                        Textarea::make('notes')->hiddenLabel()->rows(3),
                    ]),
            ]);
    }

    protected static function stayTab(): Tab
    {
        return Tab::make('الإقامة')
            ->icon(Heroicon::OutlinedBuildingOffice2)
            ->schema([
                self::detailSection('فندق المدينة', 2, 'madina'),
                self::detailSection('فندق مكة', 1, 'makka'),
            ]);
    }

    protected static function roomsTab(): Tab
    {
        return Tab::make('الغرف')
            ->icon(Heroicon::OutlinedHomeModern)
            ->badge(fn (Get $get): ?int => count($get('rooms') ?? []) ?: null)
            ->schema([
                Section::make()->schema([
                    Repeater::make('rooms')
                        ->hiddenLabel()
                        ->schema([
                            Select::make('room_type_id')
                                ->label('نوع الغرفة')
                                ->options(RoomType::query()->orderBy('size')->pluck('name', 'id'))
                                ->searchable()
                                ->preload()
                                ->live()
                                ->required()
                                ->afterStateUpdated(function (?int $state, Get $get, Set $set): void {
                                    $roomType = $state ? RoomType::query()->find($state) : null;
                                    $set('price', $roomType?->price ?? 0);
                                }),
                            TextInput::make('price')
                                ->label('السعر')
                                ->numeric()
                                ->default(0)
                                ->live(),
                            Placeholder::make('total_price')
                                ->label('الإجمالي')
                                ->content(function (Get $get): string {
                                    $roomType = RoomType::query()->find($get('room_type_id'));

                                    return number_format((float) ($get('price') ?? 0) * (int) ($roomType?->size ?? 0), 2);
                                }),
                        ])
                        ->columns(3)
                        ->defaultItems(1)
                        ->addActionLabel('إضافة غرفة'),
                ]),
            ]);
    }

    protected static function financeTab(): Tab
    {
        return Tab::make('الخدمات والمالية')
            ->icon(Heroicon::OutlinedBanknotes)
            ->schema([
                Section::make('الخدمات الإضافية')->schema([
                    TextInput::make('services_note')->label('بيان الخدمة')->maxLength(500),
                    TextInput::make('service_amount')->label('قيمة الخدمة')->numeric()->default(0)->live(),
                ])->columns(2),
                Section::make('البيانات المالية')->schema([
                    Placeholder::make('financial_total')->label('إجمالي الحجز')->content(fn (Get $get): string => number_format(self::roomsTotal($get('rooms') ?? []), 2)),
                    TextInput::make('discount')->label('التخفيض')->numeric()->default(0)->live(),
                    Placeholder::make('net_amount')->label('الصافي')->content(fn (Get $get): string => number_format(self::roomsTotal($get('rooms') ?? []) + (float) ($get('service_amount') ?? 0) - (float) ($get('discount') ?? 0), 2)),
                ])->columns(3),
            ]);
    }

    protected static function detailSection(string $label, int $cityId, string $prefix): Section
    {
        return Section::make($label)
            ->icon($cityId === 2 ? Heroicon::OutlinedBuildingLibrary : Heroicon::OutlinedBuildingOffice)
            ->visible(fn (Get $get): bool => self::scopeIncludes($get('stay_scope'), $cityId))
            ->schema([
                Hidden::make($prefix.'_city_id')->default($cityId),
                Select::make($prefix.'_hotel_id')
                    ->label('الفندق')
                    ->options(Hotel::query()->where('city_id', $cityId)->pluck('name_ar', 'id'))
                    ->searchable()
                    ->preload()
                    ->required(),
                Select::make($prefix.'_company_id')->label('الشركة')->options(Company::query()->pluck('name', 'id'))->searchable()->preload()->required(),
                Select::make($prefix.'_meal_id')->label('الوجبة')->options(Meal::query()->pluck('name', 'id'))->searchable()->preload()->required(),
                DatePicker::make($prefix.'_check_in')
                    ->label('تاريخ الدخول')
                    ->live()
                    ->afterStateUpdated(function (?string $state, Get $get, Set $set) use ($prefix): void {
                        $checkOut = $get($prefix.'_check_out');
                        if ($state && $checkOut && Carbon::parse($checkOut)->greaterThanOrEqualTo(Carbon::parse($state))) {
                            $set($prefix.'_nights', Carbon::parse($state)->diffInDays(Carbon::parse($checkOut)));
                        }
                    })
                    ->required(),
                DatePicker::make($prefix.'_check_out')
                    ->label('تاريخ الخروج')
                    ->afterOrEqual($prefix.'_check_in')
                    ->live()
                    ->afterStateUpdated(function (?string $state, Get $get, Set $set) use ($prefix): void {
                        $checkIn = $get($prefix.'_check_in');
                        if ($state && $checkIn && Carbon::parse($state)->greaterThanOrEqualTo(Carbon::parse($checkIn))) {
                            $set($prefix.'_nights', Carbon::parse($checkIn)->diffInDays(Carbon::parse($state)));
                        }
                    })
                    ->required(),
                TextInput::make($prefix.'_nights')
                    ->label('عدد الليالي')
                    ->numeric()
                    ->minValue(1)
                    ->live()
                    ->afterStateUpdated(function (?int $state, Get $get, Set $set) use ($prefix): void {
                        $checkIn = $get($prefix.'_check_in');
                        if ($checkIn && $state) {
                            $set($prefix.'_check_out', Carbon::parse($checkIn)->addDays($state)->toDateString());
                        }
                    })
                    ->dehydrated(false),
            ])->columns(3);
    }

    protected static function scopeIncludes(mixed $scope, int $cityId): bool
    {
        $scope = $scope instanceof StayScope ? $scope->value : (int) $scope;

        return $scope === 0 || ($scope === 1 && $cityId === 2) || ($scope === 2 && $cityId === 1);
    }

    protected static function roomsTotal(array $rooms): float
    {
        return collect($rooms)->sum(function (array $room): float {
            $roomType = RoomType::query()->find($room['room_type_id'] ?? null);

            return round((float) ($room['price'] ?? 0) * (int) ($roomType?->size ?? 0), 2);
        });
    }
}
