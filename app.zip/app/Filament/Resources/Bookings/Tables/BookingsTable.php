<?php

namespace App\Filament\Resources\Bookings\Tables;

use App\Actions\SimpleResourceTableActions;
use App\Enums\StayScope;
use App\Models\Hotel;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\RestoreBulkAction;
use Filament\Actions\ViewAction;
use Filament\Forms\Components\DatePicker;
use Filament\Tables\Columns\Summarizers\Sum;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\Filter;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Filters\TrashedFilter;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class BookingsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('booking_number')->label('رقم الحجز')->searchable()->sortable(),
                TextColumn::make('broker.name')->label('الفرع')->placeholder('الفرع الرئيسي')->sortable(),
                TextColumn::make('customer.name_ar')->label('ولي الأمر')->searchable(),
                TextColumn::make('bookingType.name')->label('النوع')->searchable(),
                TextColumn::make('stay_scope')->label('النطاق')->badge(),
                TextColumn::make('residents_count')->label('عدد المعتمرين')->counts('residents'),
                TextColumn::make('net_amount')->label('الصافي')->money('SAR')->sortable()->summarize(Sum::make()->money('SAR')),
                TextColumn::make('details.check_in')->label('أول دخول')->date()->sortable(),
                TextColumn::make('created_at')->label('تاريخ الإنشاء')->dateTime()->sortable(),
            ])
            ->filters([
                TrashedFilter::make(),
                SelectFilter::make('booking_type_id')->label('النوع')->relationship('bookingType', 'name'),
                SelectFilter::make('broker_id')->label('الفرع')->relationship('broker', 'name')->visible(fn (): bool => auth()->user()?->isMainAdmin() ?? false),
                SelectFilter::make('airplane_id')->label('الطيران')->relationship('airplane', 'name'),
                SelectFilter::make('stay_scope')->label('النطاق')->options(StayScope::class),
                SelectFilter::make('hotel_id')
                    ->label('الفندق')
                    ->options(fn (): array => Hotel::query()->pluck('name_ar', 'id')->all())
                    ->query(fn (Builder $query, array $data): Builder => $query->when($data['value'] ?? null, fn (Builder $query, $value): Builder => $query->whereHas('details', fn (Builder $details): Builder => $details->where('hotel_id', $value)))),
                Filter::make('check_in_range')
                    ->label('فترة الدخول')
                    ->form([
                        DatePicker::make('from')->label('من'),
                        DatePicker::make('until')->label('إلى'),
                    ])
                    ->query(fn (Builder $query, array $data): Builder => $query
                        ->when($data['from'] ?? null, fn (Builder $query, $date): Builder => $query->whereHas('details', fn (Builder $details): Builder => $details->whereDate('check_in', '>=', $date)))
                        ->when($data['until'] ?? null, fn (Builder $query, $date): Builder => $query->whereHas('details', fn (Builder $details): Builder => $details->whereDate('check_in', '<=', $date)))),
            ])
            ->recordActions([
                ViewAction::make()->label('عرض'),
                ...SimpleResourceTableActions::recordActions(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                    RestoreBulkAction::make(),
                ]),
            ])
            ->striped()
            ->defaultSort('id', 'desc')
            ->persistFiltersInSession()
            ->groups(['bookingType.name']);
    }
}
