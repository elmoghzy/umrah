<?php

namespace App\Filament\Resources\Users\Schemas;

use App\Models\User;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Utilities\Get;
use Filament\Schemas\Components\Utilities\Set;
use Filament\Schemas\Schema;

class UserForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextInput::make('name')
                    ->label('الاسم')
                    ->required(),
                TextInput::make('email')
                    ->label('البريد الإلكتروني')
                    ->email()
                    ->required(),
                TextInput::make('job')
                    ->label('الوظيفة'),
                Select::make('role')
                    ->label('نوع المستخدم')
                    ->options([
                        User::ROLE_MAIN_ADMIN => 'مدير',
                        User::ROLE_BRANCH_EMPLOYEE => 'مستخدم',
                    ])
                    ->required()
                    ->live()
                    ->afterStateUpdated(function (Set $set, ?string $state): void {
                        if ($state === User::ROLE_MAIN_ADMIN) {
                            $set('broker_id', null);
                        }
                    }),
                Select::make('broker_id')
                    ->label('الفرع')
                    ->relationship('broker', 'name')
                    ->searchable()
                    ->preload()
                    ->placeholder(fn (Get $get): string => $get('role') === User::ROLE_MAIN_ADMIN ? 'الفرع الرئيسي' : 'اختر الفرع')
                    ->disabled(fn (Get $get): bool => $get('role') !== User::ROLE_BRANCH_EMPLOYEE)
                    ->dehydrated()
                    ->required(fn (Get $get): bool => $get('role') === User::ROLE_BRANCH_EMPLOYEE),
                TextInput::make('password')
                    ->label('كلمة المرور')
                    ->password()
                    ->revealable()
                    ->minLength(8)
                    ->dehydrated(fn (?string $state): bool => filled($state))
                    ->required(fn (string $operation): bool => $operation === 'create'),
            ]);
    }
}
