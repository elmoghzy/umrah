<?php

namespace App\Filament\Resources\Users\Tables;

use Filament\Actions\DeleteAction;
use Filament\Actions\EditAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class UsersTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('الاسم')->searchable(),
                TextColumn::make('email')->label('البريد الإلكتروني')->searchable(),
                TextColumn::make('job')->label('الوظيفة')->searchable(),
                TextColumn::make('role')
                    ->label('نوع المستخدم')
                    ->formatStateUsing(fn (string $state): string => match ($state) {
                        'main_admin' => 'مدير',
                        'branch_employee' => 'مستخدم',
                        default => $state,
                    }),
                TextColumn::make('broker.name')->label('الفرع')->placeholder('الفرع الرئيسي'),
            ])
            ->filters([
                //
            ])
            ->recordActions([
                EditAction::make()->label('تعديل'),
                DeleteAction::make()->label('حذف'),
            ])
            ->striped()
            ->defaultSort('id', 'desc');
    }
}
