<!doctype html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="utf-8">
    <title>@yield('title', 'تقرير')</title>
    <style>
        @font-face { font-family: Cairo; src: url('{{ asset('fonts/cairo-variable.woff2') }}') format('woff2'); }
        @page { size: A4 portrait; margin: 0; }
        * { box-sizing: border-box; }
        html, body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        body { margin: 0; color: #111; font-family: Cairo, sans-serif; }
        .print-page { min-height: 297mm; padding: 12mm; position: relative; }
        table, th, td { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        header { padding-bottom: 8px; border-bottom: 2px solid #b68b00; text-align: center; }
        header img { max-width: 180px; max-height: 28mm; object-fit: contain; }
        header .company-name { font-size: 18px; font-weight: 700; }
        h1 { margin: 8px 0; font-size: 22px; }
        h2 { margin: 12px 0 5px; padding: 5px; background: #f4e8bf; font-size: 17px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        table { width: 100%; border-collapse: collapse; }
        thead { display: table-header-group; }
        tr { page-break-inside: avoid; }
        th, td { padding: 5px; border: 1px solid #777; }
        th { background: #f6f1df; }
        .no-print { display: block; margin: 12px auto; padding: 8px 28px; cursor: pointer; }
        .watermark { position: fixed; top: 50%; left: 50%; z-index: -1; width: 120mm; transform: translate(-50%, -50%); opacity: {{ config('umrah.watermark_opacity', 0.10) }}; pointer-events: none; }
        @media print { .no-print { display: none !important; } }
    </style>
</head>
<body>
    @if (($watermark ?? false) && is_file(public_path(config('umrah.logo_path'))))
        <img class="watermark" src="{{ asset(config('umrah.logo_path')) }}" alt="">
    @endif
    <main class="print-page">
    <header>
        @if (is_file(public_path(config('umrah.logo_path'))))
            <img src="{{ asset(config('umrah.logo_path')) }}" alt="مواكب">
        @else
            <div class="company-name">مواكب</div>
        @endif
        <div class="company-name">شركة مواكب للخدمات السياحية</div>
        <div>{{ auth()->user()?->isMainAdmin() ? 'الفرع الرئيسي' : (auth()->user()?->broker?->name ?? 'الفرع الرئيسي') }}</div>
    </header>

    <button class="no-print" onclick="window.print()">طباعة</button>

    @yield('content')
    </main>
</body>
</html>
