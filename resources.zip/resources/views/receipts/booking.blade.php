@php
    $stayScope = $booking->stay_scope?->value;
    $details = $booking->details->filter(fn ($detail) => $stayScope === 0 || ($stayScope === 1 && $detail->city_id === 2) || ($stayScope === 2 && $detail->city_id === 1));
@endphp

@extends('layouts.print')

@php($watermark = true)

@section('title', 'إيصال '.$booking->booking_number)

@section('content')
    <div class="print-section">
        <h1>إيصال إستلام مستندات سفر</h1>

    <table>
        <tr><td>رقم الإيصال</td><td>{{ $booking->booking_number }}</td><td>التاريخ</td><td>{{ $booking->created_at?->format('Y-m-d') }}</td></tr>
        <tr><td>استلمت من الأخ</td><td>{{ $booking->customer?->name_ar }}</td><td>الهاتف</td><td>{{ $booking->customer?->phone }}</td></tr>
        <tr><td>عدد الجوازات</td><td colspan="3">{{ $booking->residents->count() }}</td></tr>
    </table>

    <h2>المعتمرون</h2>
    <table>
        <thead><tr><th>ت</th><th>الاسم بالكامل</th></tr></thead>
        <tbody>
            @foreach ($booking->residents as $index => $resident)
                <tr><td>{{ $index + 1 }}</td><td>{{ $resident->customer?->name_ar }}</td></tr>
            @endforeach
        </tbody>
    </table>

    @foreach ($details as $detail)
        <h2>سكن {{ $detail->city_id === 1 ? 'مكة' : 'المدينة' }}</h2>
        <table>
            <thead><tr><th>الفندق</th><th>الدخول</th><th>الخروج</th><th>عدد الليالي</th><th>عدد الغرف</th><th>الوجبة</th></tr></thead>
            <tbody><tr>
                <td>{{ $detail->hotel?->name_ar }}</td>
                <td>{{ $detail->check_in?->format('Y-m-d') }}</td>
                <td>{{ $detail->check_out?->format('Y-m-d') }}</td>
                <td>{{ $detail->check_in?->diffInDays($detail->check_out) }}</td>
                <td>{{ $detail->rooms->count() }}</td>
                <td>{{ $detail->meal?->name }}</td>
            </tr></tbody>
        </table>
    @endforeach

    <h2>تفاصيل السعر</h2>
    <table>
        <thead><tr><th>البند</th><th>البيان</th><th>السعر</th></tr></thead>
        <tbody>
            <tr><td>الخدمات الإضافية</td><td>{{ $booking->services_note }}</td><td>{{ number_format((float) $booking->service_amount, 2) }}</td></tr>
            <tr><td>السعر</td><td colspan="2">{{ number_format((float) $booking->total_amount, 2) }}</td></tr>
            <tr><th>الصافي</th><th colspan="2">{{ number_format((float) $booking->net_amount, 2) }}</th></tr>
        </tbody>
    </table>

    <p><strong>تاريخ السفر:</strong> {{ $details->sortBy('check_in')->first()?->check_in?->format('Y-m-d') }}</p>
    <p><strong>ملاحظات:</strong> {{ $booking->notes }}</p>
    <p><strong>المستلم:</strong> {{ auth()->user()?->name }}</p>
        <div style="text-align: center">{!! $qr !!}</div>
    </div>
@endsection
